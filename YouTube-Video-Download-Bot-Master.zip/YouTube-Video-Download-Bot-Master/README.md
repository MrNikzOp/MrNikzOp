#### YouTube Video Download Bot V2 
###### This A simple YouTube Video Download Telegram Bot


![logo](https://graph.org/file/754b7faa1308a13fc917f.jpg)


# How To Deploy

<b><details><summary>Tap To watch</summary>

### Heroku Video
<a href="https://youtu.be/ms_ApEgb0SA?feature=shared"><img alt="how to create" src="https://img.shields.io/badge/-YouTube-red?style=for-the-badge&logo=youtube&logoColor=white"/></a> 

### Render Video
<a href="https://youtu.be/A4l6LSPi-lM?feature=shared"><img alt="how to create" src="https://img.shields.io/badge/-YouTube-red?style=for-the-badge&logo=youtube&logoColor=white"/></a>

</b>
</details>

## Environment Variable

* `APP_ID` Get it From mytelegram.org

* `API_HASH` Get it From mytelegram.org

* `BOT_TOKEN` Get it from [@Botfather](https://t.me/botfather)


### Bot Commands 
```
start - Check Bot Online 🔔
help - How To Use The Bot 🆘
about - Something About Me 😌

```

### My Community Details


- YouTube Channel : [Telegram Bots 🤖](https://youtube.com/@NTBOT?feature=shared)
- Telegram Channel : [NT Bots ❤️‍🩹](https://t.me/NT_BOT_CHANNEL)
- Telegram Group : [NT Bots Support 🎗️](https://t.me/NT_BOTS_SUPPORT)
- URL Uploader Bot : [Uploader Bot 🚀](https://t.me/UploadLinkToFileBot)
- My Tg Id : [Lisa 👑](https://t.me/LISA_FAN_LK)
